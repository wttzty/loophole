## template

    模板目录需要跟插件plagins里模块名保持一致
